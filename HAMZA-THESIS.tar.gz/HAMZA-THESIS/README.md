# Validation numérique OpenFOAM — Écoulement autour d'une plaque plane inclinée (30°)

Reproduction sous OpenFOAM v2506 de l'étude de validation de Raciti Castelli et al. (2012),
confrontée aux mesures historiques de Fage & Johansen (1927).

Trois modèles de turbulence RANS de la famille k-ε (Standard, Realizable, RNG) sont comparés
sur quatre niveaux de raffinement de maillage (MOD1 à MOD4, générés par un pipeline
automatisé gmsh/Python reproduisant les paramètres de l'article de référence).

## Résultats — coefficient de force normale kN

kN = FN / (ρ · b · V0²), comparé à la valeur expérimentale de Fage & Johansen : **kN = 0.645** (à 30°)

| Maillage (cellules) | Std-Keps | Realizable | RNG |
|---|---|---|---|
| MOD1 (~1 017 000) | 0.704 (+9.1%) | 0.735 (+14.0%) | 0.633 (-1.9%) |
| MOD2 (~992 000)   | 0.674 (+4.5%) | **diverge, non exploitable** | 0.686 (+6.4%) |
| MOD3 (~978 000)   | 0.680 (+5.4%) | 0.646 (+0.2%) | 0.669 (+3.7%) |
| MOD4 (~245 000)   | 0.689 (+6.9%) | 0.6455 (+0.08%) | 0.669 (+3.7%) |

## Observation principale

Le modèle **Realizable k-ε** donne le meilleur résultat ponctuel sur maillage grossier
(MOD4, écart < 0.1% avec l'expérience), confirmant la conclusion de Raciti Castelli et al.
Mais son comportement n'est **pas monotone avec le raffinement du maillage** : il devient
instable sur MOD2 (divergence numérique, voir `resultats/MOD2/Realizable_DIVERGE/`) et
oscille en permanence sans jamais se stabiliser sur MOD3 (voir
`resultats/MOD3/Realizable/kN_convergence.png`), avant de donner son résultat le plus
éloigné de l'expérience sur le maillage le plus fin (MOD1, +14.0%).

Le modèle **RNG k-ε** est nettement plus robuste sur l'ensemble des maillages testés
(entre -1.9% et +6.4%, jamais de divergence), bien que légèrement moins précis dans le
meilleur des cas.

Le modèle **Standard k-ε** est le plus prévisible mais présente un biais systématique de
sur-estimation (+4.5% à +9.1%) sur tous les maillages.

Ce comportement non-monotone de Realizable n'est pas discuté dans l'article de référence
(qui ne teste pas au-delà d'un maillage équivalent à notre MOD1). C'est un point de
discussion identifié pour la suite du travail (passage à l'instationnaire).

## Notes sur des points à vérifier / limitations connues

- **Realizable/MOD2** : le calcul diverge numériquement (Cd devient négatif, résidu de
  pression qui remonte après l'itération ~4200 au lieu de continuer à descendre). Résultat
  exclu du tableau. Fichiers conservés dans `resultats/MOD2/Realizable_DIVERGE/` à titre
  de documentation. Piste à explorer : réduire les facteurs de sous-relaxation ou repartir
  d'un schéma numérique plus dissipatif (`upwind`) avant de raffiner.
- **RNG/MOD2** : le calcul a été interrompu une fois par une coupure machine, repris avec
  `startFrom latestTime`, ce qui a produit deux fichiers `force.dat` distincts
  (`postProcessing/forcesPlate/0/` et `.../6600/`). Les deux ont été fusionnés manuellement
  avant de recalculer le kN définitif (0.686) — voir `kN_convergence_CORRIGE.png`.
- **MOD4** : les résultats numériques (0.689 / 0.6455 / 0.669) proviennent du tout premier
  calcul de cette étude et sont fiables
- **Réalisable/MOD3** : converge vers un bon kN moyen (0.646) mais oscille en permanence
  sans jamais atteindre un plateau stable — signe d'un caractère instationnaire de
  l'écoulement que le solveur stationnaire (simpleFoam) peine à figer.

## Contenu du dépôt

```
scripts/                        Scripts Python de post-traitement
  plot_residuals.py              Courbes de convergence des résidus (depuis log.simpleFoam)
  plot_kN_convergence.py         Convergence du coefficient kN (depuis postProcessing/forcesPlate)
  plot_field_paraview.py         Champ de vitesse + profils bord d'attaque/fuite (pvpython)
  plot_velocity_profiles.py      Trace les profils de vitesse depuis les CSV ParaView

resultats/
  MOD1/{Std-Keps,Realizable,RNG}/       kN_convergence.png, residuals.png
  MOD2/{Std-Keps,RNG}/                  kN_convergence.png, residuals.png
  MOD2/Realizable_DIVERGE/              résultat invalide, conservé pour documentation
  MOD3/{Std-Keps,Realizable,RNG}/       kN_convergence.png, residuals.png
  MOD3/Std-Keps/                        + champ_vitesse_pathlines.png, profils bord attaque/fuite
```

## Référence expérimentale et article reproduit

- A. Fage, F. C. Johansen, *On the flow of air behind an inclined flat plate of infinite
  span*, Proc. Royal Society A, 116 (1927), 170-197.
- M. Raciti Castelli, P. Cioppa, E. Benini, *Numerical simulation of the flow field around
  a 30° inclined flat plate*, Int. J. Aerospace and Mechanical Engineering, 6(3) (2012), 692-697.
