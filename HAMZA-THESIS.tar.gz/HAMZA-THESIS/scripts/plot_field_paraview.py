#!/usr/bin/env python3
"""
Genere le champ de vitesse (type Fig. 12 de Raciti Castelli et al.) et les
profils de vitesse au bord d'attaque / bord de fuite (type Fig. 10/11),
avec la geometrie EXACTE de la plaque tournee a 30 degres (meme convention
que mod4.py : plaque centree a l'origine, tournee autour de son centre).

A executer avec pvpython, depuis le dossier du cas :
    pvpython plot_field_paraview.py
"""
import os
import math
from paraview.simple import *

# ============================================================
# Geometrie de la plaque (doit rester identique a mod4.py)
# ============================================================
CHORD = 0.1511          # corde b [m]
ALPHA_DEG = 30.0        # angle d'incidence [deg]
alpha = math.radians(ALPHA_DEG)
c, sn = math.cos(alpha), math.sin(alpha)

# Bord d'attaque (L.E.) et bord de fuite (T.E.) en coordonnees globales,
# obtenus en tournant les points locaux (-L/2,0) et (+L/2,0) autour de
# l'origine (meme rotation que dans mod4.py : xr = c*x - sn*y, yr = sn*x + c*y)
xLE, yLE = c * (-CHORD / 2), sn * (-CHORD / 2)
xTE, yTE = c * (+CHORD / 2), sn * (+CHORD / 2)

# Decalages des lignes de mesure par rapport aux bords (Table XI de l'article,
# distances le long de l'ecoulement, X1 pour T.E., X2 pour L.E.)
X_OFFSET_TE = 0.0704
X_OFFSET_LE = 0.0604

# ============================================================
# Chargement du cas OpenFOAM
# ============================================================
foam_file = "case.foam"
if not os.path.exists(foam_file):
    open(foam_file, "w").close()

reader = OpenFOAMReader(FileName=foam_file)
reader.MeshRegions = ["internalMesh"]
reader.CellArrays = ["U", "p"]
reader.UpdatePipeline()

scene = GetAnimationScene()
scene.UpdateAnimationUsingDataTimeSteps()
scene.GoToLast()

view = GetActiveViewOrCreate("RenderView")
view.ViewSize = [1600, 900]
view.OrientationAxesVisibility = 0
view.Background = [1, 1, 1]

disp = Show(reader, view)
ColorBy(disp, ("POINTS", "U", "Magnitude"))
disp.RescaleTransferFunctionToDataRange(True)
disp.SetScalarBarVisibility(view, True)
lut = GetColorTransferFunction("U")
lut.ApplyPreset("Rainbow Uniform", True)

# Lignes de courant, semees juste en amont de la plaque (perpendiculairement
# a l'ecoulement), assez longues pour traverser tout le sillage proche
stream = StreamTracer(Input=reader, SeedType="Line")
stream.Vectors = ["POINTS", "U"]
stream.SeedType.Point1 = [xLE - 3 * CHORD, -3 * CHORD, 0.0]
stream.SeedType.Point2 = [xLE - 3 * CHORD, 3 * CHORD, 0.0]
stream.SeedType.Resolution = 50
stream.MaximumStreamlineLength = 15 * CHORD
streamDisp = Show(stream, view)
ColorBy(streamDisp, ("POINTS", "U", "Magnitude"))

# Cadrage explicite : plaque + sillage proche (jusqu'a ~6 cordes en aval),
# NE PAS utiliser ResetCamera seul, qui cadre sur tout le domaine (12/25 cordes)
view.CameraParallelProjection = 1
view.CameraFocalPoint = [xTE + 1.5 * CHORD, 0.0, 0.0]
view.CameraPosition = [xTE + 1.5 * CHORD, 0.0, 1.0]
view.CameraViewUp = [0, 1, 0]
view.CameraParallelScale = 4 * CHORD
Render(view)

SaveScreenshot("champ_vitesse_pathlines.png", view, ImageResolution=[1600, 900])
print("Figure sauvegardee: champ_vitesse_pathlines.png")

# ============================================================
# Profils de vitesse au bord d'attaque / bord de fuite (Fig. 10/11)
# Lignes verticales (perpendiculaires a l'ecoulement), positionnees a
# l'offset X_OFFSET depuis le bord CORRESPONDANT (pas depuis x=0),
# centrees sur la coordonnee y du bord correspondant.
# ============================================================
configs = [
    ("bord_attaque", xLE + X_OFFSET_LE, yLE, -1),  # cote L.E., y/b negatif
    ("bord_fuite",   xTE + X_OFFSET_TE, yTE, +1),  # cote T.E., y/b positif
]

for name, x_line, y_edge, sign in configs:
    y_start = y_edge + sign * 0.10 * CHORD
    y_end = y_edge + sign * 0.50 * CHORD
    plot_line = PlotOverLine(Input=reader)
    plot_line.Point1 = [x_line, y_start, 0.0]
    plot_line.Point2 = [x_line, y_end, 0.0]
    plot_line.Resolution = 200
    plot_line.UpdatePipeline()
    writer = CreateWriter(f"profil_{name}.csv", plot_line)
    writer.UpdatePipeline()
    print(f"CSV sauvegarde: profil_{name}.csv (x={x_line:.5f}, y_edge={y_edge:.5f})")

# Sauvegarde des coordonnees des bords pour que plot_velocity_profiles.py
# normalise le y/b de la meme facon (offset par rapport au bord, pas y absolu)
with open("plate_edges.txt", "w") as f:
    f.write(f"{xLE} {yLE} {xTE} {yTE} {CHORD}\n")
