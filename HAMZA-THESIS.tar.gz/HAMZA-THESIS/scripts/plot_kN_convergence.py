#!/usr/bin/env python3
"""
Trace la convergence du coefficient de force normale kN
a partir de postProcessing/forcesPlate/0/force.dat.

Reprend exactement le calcul de force_auto.sh :
    FN_par_m = |Fx*sin(alpha) + Fy*cos(alpha)| / thick
    kN       = FN_par_m / (rho * V0^2 * chord)

Usage:
    python3 plot_kN_convergence.py [force.dat] [alpha_deg] [rho] [Uinf] [chord] [thick]

Valeurs par defaut = celles du cas Std-Keps / MOD4 (plaque a 30 degres).
Dependance: matplotlib (pip install matplotlib --break-system-packages)
"""
import sys
import os
import math
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

force_file = sys.argv[1] if len(sys.argv) > 1 else "postProcessing/forcesPlate/0/force.dat"
_abs = os.path.abspath(force_file)
# force_file typique: <mesh>/<modele>/postProcessing/forcesPlate/0/force.dat
_case_dir = _abs
for _ in range(4):
    _case_dir = os.path.dirname(_case_dir)
cas_label = os.path.basename(_case_dir) or "?"
mesh_label = os.path.basename(os.path.dirname(_case_dir)) or "?"
alpha_deg  = float(sys.argv[2]) if len(sys.argv) > 2 else 30.0
rho        = float(sys.argv[3]) if len(sys.argv) > 3 else 1.225
Uinf       = float(sys.argv[4]) if len(sys.argv) > 4 else 15.25
chord      = float(sys.argv[5]) if len(sys.argv) > 5 else 0.1511
thick      = float(sys.argv[6]) if len(sys.argv) > 6 else 0.005

alpha = math.radians(alpha_deg)
ref = rho * Uinf ** 2 * chord

times, kNs = [], []
with open(force_file) as f:
    for line in f:
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        parts = line.split()
        t = float(parts[0])
        fx = float(parts[1])
        fy = float(parts[2])
        fn_par_m = abs(fx * math.sin(alpha) + fy * math.cos(alpha)) / thick
        kN = fn_par_m / ref
        times.append(t)
        kNs.append(kN)

n = len(kNs)
half = kNs[n // 2:] if n > 1 else kNs
kN_mean = sum(half) / len(half)

plt.figure(figsize=(9, 6))
plt.plot(times, kNs, label="kN instantane", linewidth=1.2)
plt.axhline(kN_mean, color="green", ls="--", label=f"kN moyen (2e moitie) = {kN_mean:.3f}")
plt.axhline(0.645, color="red", ls="-", linewidth=1.5, label="Experience Fage & Johansen = 0.645")
plt.axhline(0.826, color="orange", ls=":", linewidth=1.5, label="Article MOD4, Table VII = 0.826")
plt.xlabel("Iteration")
plt.ylabel("kN [-]")
plt.title(f"Convergence du coefficient de force normale kN ({mesh_label}, {cas_label})")
plt.legend()
plt.grid(True, ls=":")
plt.tight_layout()
plt.savefig("kN_convergence.png", dpi=200)
print(f"kN moyen (2e moitie des donnees) : {kN_mean:.4f}")
print("Figure sauvegardee: kN_convergence.png")
