#!/usr/bin/env python3
"""
Trace les profils de vitesse V/V0 en fonction de y/b (type Fig. 10 et 11
de Raciti Castelli et al.), normalises PAR RAPPORT AU BORD correspondant
(comme dans l'article), a partir des CSV generes par plot_field_paraview.py.

Usage (apres avoir lance pvpython plot_field_paraview.py) :
    python3 plot_velocity_profiles.py
"""
import csv
import math
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

UINF = 15.25

# Lit les coordonnees des bords calculees par plot_field_paraview.py
with open("plate_edges.txt") as f:
    xLE, yLE, xTE, yTE, CHORD = map(float, f.read().split())


def read_profile(path):
    ys, vmag = [], []
    with open(path) as f:
        reader = csv.DictReader(f)
        for row in reader:
            y = float(row["Points:1"])
            ux = float(row["U:0"])
            uy = float(row["U:1"])
            v = math.hypot(ux, uy)
            ys.append(y)
            vmag.append(v)
    return ys, vmag


configs = [
    ("bord_attaque", "Leading Edge", yLE, -1),
    ("bord_fuite", "Trailing Edge", yTE, +1),
]

for name, title, y_edge, sign in configs:
    try:
        ys, vmag = read_profile(f"profil_{name}.csv")
    except FileNotFoundError:
        print(f"profil_{name}.csv introuvable — lance d'abord pvpython plot_field_paraview.py")
        continue
    # y/b mesure depuis le bord ; la ligne ne balaie qu'un seul cote
    # (voir Point1/Point2 dans plot_field_paraview.py), donc pas besoin
    # de forcer un signe ou une valeur absolue ici.
    yb = [(y - y_edge) / CHORD for y in ys]
    vv0 = [v / UINF for v in vmag]

    order = sorted(range(len(yb)), key=lambda i: yb[i])
    yb = [yb[i] for i in order]
    vv0 = [vv0[i] for i in order]

    plt.figure(figsize=(6, 6))
    plt.plot(yb, vv0, marker="o", markersize=3, label="Numerique (ta simulation)")
    plt.xlabel("y/b [-]")
    plt.ylabel("V/V0 [-]")
    plt.title(title)
    plt.grid(True, ls=":")
    plt.legend()
    plt.tight_layout()
    outname = f"profil_{name}.png"
    plt.savefig(outname, dpi=200)
    print(f"Figure sauvegardee: {outname}")
