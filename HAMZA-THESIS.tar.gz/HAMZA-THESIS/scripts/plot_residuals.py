#!/usr/bin/env python3
"""
Trace les courbes de convergence des residus a partir de log.simpleFoam.
Remplace "gnuplot Residuals -" par une figure matplotlib exportable.

Usage:
    python3 plot_residuals.py [log.simpleFoam]

Dependance: matplotlib
    pip install matplotlib --break-system-packages
"""
import sys
import re
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

logfile = sys.argv[1] if len(sys.argv) > 1 else "log.simpleFoam"
_abs = os.path.abspath(logfile)
cas_label = os.path.basename(os.path.dirname(_abs)) or "?"
mesh_label = os.path.basename(os.path.dirname(os.path.dirname(_abs))) or "?"

fields = ["Ux", "Uy", "p", "k", "epsilon"]
data = {f: [] for f in fields}

current_time = None
with open(logfile) as f:
    for line in f:
        m = re.match(r"Time = (\d+)", line)
        if m:
            current_time = int(m.group(1))
            continue
        m = re.search(r"Solving for (\w+), Initial residual = ([\d.eE+-]+)", line)
        if m and current_time is not None:
            field, val = m.group(1), float(m.group(2))
            if field in fields:
                if not data[field] or data[field][-1][0] != current_time:
                    data[field].append((current_time, val))

plt.figure(figsize=(9, 6))
for f in fields:
    if data[f]:
        ts = [p[0] for p in data[f]]
        vs = [p[1] for p in data[f]]
        plt.semilogy(ts, vs, label=f, linewidth=1.2)

plt.xlabel("Iteration")
plt.ylabel("Residu initial")
plt.title(f"Convergence des residus - simpleFoam ({mesh_label}, {cas_label})")
plt.legend()
plt.grid(True, which="both", ls=":")
plt.tight_layout()
plt.savefig("residuals.png", dpi=200)
print("Figure sauvegardee: residuals.png")
print(f"Champs trouves: {[f for f in fields if data[f]]}")
print(f"Nombre d'iterations tracees: {len(data['Ux']) if data['Ux'] else 0}")
